package ch07;

public class 연습문제02Main_답 {
  public static void main(String[] args) {
    연습문제02_답 e = new 연습문제02_답();
    e.content = "Hello World!";
    e.latitude = 33.450701f;
    e.longitude = 126.570667f;
    
    System.out.println(e);
  }
}
