package ch08;

public class 연습문제01_답 {
  float bottom;
  float height;
  
  // 기본 생성자 작성
  public 연습문제01_답() {}
  
  // 매개변수 2개 생성자 작성
  public 연습문제01_답(float bottom, float height) {
    this.bottom = bottom;
    this.height = height;
  }
  
  // getArea 메소드 작성
  public float getArea() {
    return bottom * height;
  }

  // bottom과 height의 setter 메소드 작성
  public void setBottom(float bottom) {
    this.bottom = bottom;
  }
  
  public void setHeight(float height) {
    this.height = height;
  }

}
