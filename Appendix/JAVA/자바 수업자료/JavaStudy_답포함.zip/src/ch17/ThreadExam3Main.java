package ch17;

public class ThreadExam3Main {
  public static void main(String[] args) {
    ThreadExam3 t = new ThreadExam3();
    t.start();
  }
}
