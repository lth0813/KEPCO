package ch04;

public class 연습문제05_답 {
  public static void main(String[] args) {
    int n = 5;
    int space = 0;

    for(int row = 1; row <= n; row++) {
      space = n - row;
      for(int col = 1; col <= n; col++) {
        if(col <= space) {
          System.out.print(" ");
        } else {
          System.out.print("*");
        }
      }
      System.out.println();
    }
  }
}
