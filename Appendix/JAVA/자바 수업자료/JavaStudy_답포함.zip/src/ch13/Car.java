package ch13;

public abstract class Car {
  public abstract void move();
}
