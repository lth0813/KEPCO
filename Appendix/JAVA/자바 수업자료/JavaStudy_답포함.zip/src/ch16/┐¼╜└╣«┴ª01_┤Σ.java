package ch16;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class 연습문제01_답 {
  public static void main(String[] args) throws IOException {
    OutputStream out = new FileOutputStream("src/ch16/output.txt");
    out.write((int)'F');
    out.write((int)'i');
    out.write((int)'l');
    out.write((int)'e');
    out.write((int)'\n');
    out.write((int)'O');
    out.write((int)'u');
    out.write((int)'t');
    out.write((int)'p');
    out.write((int)'u');
    out.write((int)'t');
    out.flush();
    out.close();
  }
}
