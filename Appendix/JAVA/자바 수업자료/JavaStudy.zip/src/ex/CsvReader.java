package ex;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class CsvReader {
  public static void main(String[] args) throws IOException {
    CsvReader.readToList("data/seoul_기온.csv");
  }
  
  public static void readToList(String path) throws IOException {
    File csv = new File(path);
    BufferedReader br = null;
    br = new BufferedReader(new FileReader(csv));
  
    String line = "";
  
    while (true) {
      line = br.readLine();
      if(line == null) break;
      System.out.println(line);
    }
  
    br.close();
  }
}
