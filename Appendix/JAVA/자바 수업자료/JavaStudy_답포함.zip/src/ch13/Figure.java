package ch13;

public abstract class Figure {
  public abstract void area(int x, int y);
}
