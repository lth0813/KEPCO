package ch13;

public class AsusRouter extends Router {
  public String connect() {
    return "asus connect";
  }
  public String disconnect() {
    return "asus disconnect";
  }
}
