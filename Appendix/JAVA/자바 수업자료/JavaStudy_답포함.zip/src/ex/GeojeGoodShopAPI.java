package ex;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

public class GeojeGoodShopAPI {
  public static final String authApiKey = "A2usf4txsthrBPXx7%2FckSjISrlOOF3DRCXlpwxFKcl1KPyvOOWSD%2FUhcapvCkM51AdZOieooIvkMdz2XQCt33w%3D%3D";
  
  public static void main(String[] args) throws IOException {
    int pageSize = 30;
    
    String apiURL = "http://data.geoje.go.kr/rfcapi/rest/geojegoodshop/getGeojegoodshopList";
    apiURL += "?authApiKey=" + authApiKey;
    apiURL += "&pageSize=" + pageSize;
    
    URL url = new URL(apiURL);
    HttpURLConnection con = (HttpURLConnection) url.openConnection();
    con.setRequestProperty("accept", "application/json");
    
    ObjectMapper objectMapper = new ObjectMapper();
    Map object = objectMapper.readValue(con.getInputStream(), Map.class);
    System.out.println(object);
    
    Map body = (Map) object.get("body");
    Map data = (Map) body.get("data");
    List list = (List) data.get("list");
    
    Writer writer = new FileWriter("geoje-goodshop.txt");
    
    for(int i = 0; i < list.size(); i++) {
      Map shop = (Map) list.get(i);
      String id = (String) shop.get("goodshopId");
      String name = (String) shop.get("goodshopNm");
      String cdNm = (String) shop.get("goodshopCdNm");
      String info = (String) shop.get("goodshopInfo");
      System.out.println(
          id + " | " + name + " | " + cdNm + " | " + info);
      writer.write(id + " | " + name + " | " + cdNm + " | " + info);
      writer.write("\n");
    }
    writer.close();
  }
}
