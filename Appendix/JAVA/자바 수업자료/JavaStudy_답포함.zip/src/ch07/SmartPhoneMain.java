package ch07;

public class SmartPhoneMain {
  public static void main(String[] args) {
    SmartPhone sp = new SmartPhone();
    sp.company = "삼성";
    sp.name = "갤럭시";
    sp.size = 7.0f;
    sp.price = 100000;

    SmartPhone sp2 = new SmartPhone();
    sp2.company = "LG";
    sp2.name = "G8";
    sp2.size = 6.0f;
    sp2.price = 200000;

    sp.volumeUp();
    sp.powerOff();

    sp2.volumeDown();
    sp2.powerOn();
  }
}
