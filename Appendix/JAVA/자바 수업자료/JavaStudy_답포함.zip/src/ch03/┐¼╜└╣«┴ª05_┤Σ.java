package ch03;

public class 연습문제05_답 {
  public static void main(String[] args) {
    char ch = 'T';
    
    char lowerCase = ( ch >= 'A' && ch <= 'Z' ) ? (char) ( ch + 32 ) : ch;
    
    System.out.println("입력된 문자 : " + ch);
    System.out.println("소문자로 변경된 문자 : " + lowerCase);
  }
}
