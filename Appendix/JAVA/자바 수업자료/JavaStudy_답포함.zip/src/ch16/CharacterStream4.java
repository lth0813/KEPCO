package ch16;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class CharacterStream4 {
  public static void main(String[] args) throws IOException {
    Writer writer = new FileWriter("chracter-stream-write.txt");
    
    char[] array = {
      (int)'J', (int)'a', (int)'v', (int)'a'
    };
    
    writer.write(array);
    
    writer.flush();
    writer.close();
  }
}
