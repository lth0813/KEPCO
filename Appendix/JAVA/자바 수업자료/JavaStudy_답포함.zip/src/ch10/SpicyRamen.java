package ch10;

public class SpicyRamen      { // 상속 코드 작성
//  public SpicyRamen(String name) {
//    super.name = name;
//  }

  // 오버라이드 코드 작성

  
  
  
}