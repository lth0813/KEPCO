package ch14;

public class WrongPasswordException extends Exception {




}
