package ch06;

public class 연습문제04_답 {
  public static void main(String[] args) {
    boolean a = false;
    boolean b = false;
    System.out.println(dilemma(a, b));
  }
  
  public static String dilemma(boolean a, boolean b) {
    String result = "";
    
    if(a && b) result = "A, B 둘다 5년 복역";
    else if(a && !b) result = "A 석방, B 10년 복역";
    else if(!a && b) result = "A 10년 복역, B 석방";
    else result = "A, B 둘다 1년 복역";
    
    return result;
  }
}
