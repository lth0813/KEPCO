package ch10;

public class SuperThis1 {
  public static void main(String[] args) {
    Bottom bottom = new Bottom();
    bottom.show(20);
  }
}
