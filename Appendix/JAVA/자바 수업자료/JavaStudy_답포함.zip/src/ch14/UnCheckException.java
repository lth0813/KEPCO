package ch14;

public class UnCheckException extends RuntimeException {

  public UnCheckException(String message) {
    super(message);
  }
  
}
 