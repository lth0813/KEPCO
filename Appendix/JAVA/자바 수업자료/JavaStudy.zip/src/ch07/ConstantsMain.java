package ch07;

public class ConstantsMain {
  public static void main(String[] args) {
    System.out.println(Constants.HOBBY_SWIMMING);
    System.out.println(Constants.HOBBY_TENNIS);
    System.out.println(Constants.HOBBY_EAT);
  }
}
