package ch07;

public class Initialize2 {
// 1. 명시적 초기화
int a = 10;
int b = 20;

// 2. 초기화 블럭
{
  System.out.println("= 초기화 블럭 =");
  System.out.printf("a : %s, b : %s\n", a, b);
  a = 40;
  b = 50;
}

// 3. 생성자
public Initialize2() {
  System.out.println("= 생성자 =");
  System.out.printf("a : %s, b : %s\n", a, b);
  a = 20;
  b = 30;
}

public static void main(String[] args) {
  Initialize2 i = new Initialize2();

  System.out.println("= 객체 생성 후 =");
  System.out.printf("a : %s, b : %s\n", i.a, i.b);
}
}
