package ch05;

import java.util.Arrays;

public class ArrayCopy {
  public static void main(String[] args) {
    int[] arr = new int[3];
    
    arr[0] = 0;
    arr[1] = 1;
    arr[2] = 2;
    
    int[] arr2 = new int[5];
    
    System.arraycopy(arr, 0, arr2, 0, arr.length);
    
    arr2[3] = 3;
    arr2[4] = 4;
    
    System.out.println("원본 : " + Arrays.toString(arr));
    System.out.println("복사본 : " + Arrays.toString(arr2));
  }
}
