package ch13;

public class Button {
  public void setOnClickListener(
      OnClickListener onClickListener) {
    onClickListener.onClick();
  }
}
