package ch01;

public class 연습문제01 {
  public static void main(String[] args) {
    System.out.println(  );
    System.out.println(  );
    
    int a = 1, b = 2, c = 3, d = 4, e = 5;
    System.out.println(  );// a ~ e 변수를 활용하여 연산
  }
}
