package ch02;

public class Variable2 {
  public static void main(String[] args) {

    boolean isFile = false; // 논리

    char ch = 'A'; // 문자

// 숫자 (정수)
    byte bt = 10;
    short count = 100;
    int age = 3000;
    long ms = 20000;

// 숫자 (실수)
    float avg = 99.99f;
    double pro = 1234.12312313d;

// 특수문자
    int abc$;
    int $abc;
    int abc_;
    int _abc;
  }
}
