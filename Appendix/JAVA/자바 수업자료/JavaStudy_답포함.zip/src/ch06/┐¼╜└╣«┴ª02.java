package ch06;

public class 연습문제02 {
  public static void main(String[] args) {
    
  }
  
  
  
  
}
