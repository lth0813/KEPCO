package ch14;

public class NotExistIdException extends Exception {




}
