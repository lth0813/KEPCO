package ch13;

public class AbstractImpl extends AbstractChild {

  @Override
  public void run() {
    /* 코드 작성 */
  }

  @Override
  public void walk() {
    /* 코드 작성 */
  }
  
}
