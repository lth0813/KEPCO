package ch07;

public class 연습문제03Main_답 {
  public static void main(String[] args) {
    연습문제03_답.method1();
  }
}
