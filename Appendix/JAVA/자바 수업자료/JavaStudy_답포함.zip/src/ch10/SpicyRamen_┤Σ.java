package ch10;

public class SpicyRamen_답 extends Ramen_답 { // 상속 코드 작성
  public SpicyRamen_답(String name) {
    super.name = name;
  }

  // 오버라이드 코드 작성
  @Override
  public String getTaste() {
    return this.name + " => " + "매운 라면맛";
  }  
  
}