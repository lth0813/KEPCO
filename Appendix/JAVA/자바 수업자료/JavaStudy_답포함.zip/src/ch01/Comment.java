package ch01;

// 작성자 : 개발자
// 작성일 : 20XX년 XX월 XX일 
// 작성이유 : System.out.println 메소드 기능 테스트
public class Comment {
  /**
   * 주석 사용법
   */
  public static void main(String[] args) {
    /*
     * 여러줄 주석
     */
  }

}
