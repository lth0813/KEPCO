package ch06;

import java.util.Random;

public class MethodExam3 {
public static void main(String[] args) {
  int number = getRandomNumber(60, 100);
  System.out.println(number);
}

public static int getRandomNumber(int startNum, int endNum) {
  Random random = new Random();
  int number = 0;
  while (true) {
    number = random.nextInt(endNum);
    if (number >= startNum) {
      break;
    }
  }
  return number;
}
}
