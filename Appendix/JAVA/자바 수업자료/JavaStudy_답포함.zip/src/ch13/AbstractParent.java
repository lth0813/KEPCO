package ch13;

public abstract class AbstractParent {
  public abstract void walk();
}
