package ch16;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class 연습문제02_답 {
  public static void main(String[] args) throws IOException {
    InputStream in = new FileInputStream("data/harry_potter.txt");
    while(true) {
      int data = in.read();
      if(data == -1) break;
      System.out.print((char) data);
    }
    
    in.close();
  }
}
