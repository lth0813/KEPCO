package ch02;

public class Overflow {
  public static void main(String[] args) {
    byte b = 127;
    b = (byte) (b + 1); // -128
    System.out.println(b);

    int num1 = 300;
    byte num2 = (byte) (num1); // 44
    System.out.println(num2);
  }
}
