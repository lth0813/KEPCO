package ex;

public class MailerMain {
  public static void main(String[] args) {
    Mailer mailer = new Mailer();
    
    mailer.sendMailGoogle(
        "ssaltoki@naver.com", "제목", "내용", new SMTPAuthenticatorGoogle());
    
    mailer.sendMailNaver(
        "ggoreb.kim@gmail.com", "제목", "내용", new SMTPAuthenticatorNaver());
  }
}
