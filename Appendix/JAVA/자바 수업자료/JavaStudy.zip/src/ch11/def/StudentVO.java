package ch11.def;

public class StudentVO {
  int grade;
  int classNum;
  String name;
}
