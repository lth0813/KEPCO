package ch15;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetIteratorExam {
  public static void main(String[] args) {
    HashSet<String> data = new HashSet<String>();
    
    data.add("1번");
    data.add("2번");
    data.add("3번");
    data.add("A");
    data.add("B");
    data.add("가");
    data.add("아");

    Iterator<String> iter = data.iterator();
    while (iter.hasNext()) {
      String item = iter.next();
      System.out.println(item);
    }
  }
}
