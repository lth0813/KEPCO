package db.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import db.DBConnector;
import db.dto.ShopDto;

public class ShopDao {
  
  public int save(ShopDto shopDto) {
    makeDB();
    
    Connection con = DBConnector.open();
    PreparedStatement stmt = null;
    
    int result = 0;

    try {
      StringBuffer sql = new StringBuffer();
      sql.append("INSERT INTO shop");
      sql.append("  (id, name, address, info, tel, code, codeName, mainImg)");
      sql.append("  VALUES");
      sql.append("  (?, ?, ?, ?, ?, ?, ?, ?)");      
      
      stmt = con.prepareStatement(sql.toString());
      stmt.setInt(1, shopDto.getId());
      stmt.setString(2, shopDto.getName());
      stmt.setString(3, shopDto.getAddress());
      stmt.setString(4, shopDto.getInfo());
      stmt.setString(5, shopDto.getTel());
      stmt.setString(6, shopDto.getCode());
      stmt.setString(7, shopDto.getCodeName());
      stmt.setString(8, shopDto.getMainImg());
      
      result = stmt.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      DBConnector.close(con, stmt, null);
    }
    return result;
  }
  
  private boolean makeDB() {
    Connection con = DBConnector.open();
    PreparedStatement stmt = null;
    
    int result = 0;
    
    try {
      StringBuffer sql = new StringBuffer();
      sql.append("CREATE TABLE IF NOT EXISTS shop (");
      sql.append("  id INTEGER PRIMARY KEY,");
      sql.append("  name TEXT,");
      sql.append("  address TEXT,");
      sql.append("  info TEXT,");
      sql.append("  tel TEXT,");
      sql.append("  code TEXT,");
      sql.append("  codeName TEXT,");
      sql.append("  mainImg TEXT");
      sql.append(");");      
      
      stmt = con.prepareStatement(sql.toString());      
      result = stmt.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      DBConnector.close(con, stmt, null);
    }
    return result == 1 ? true : false;
  }
}
