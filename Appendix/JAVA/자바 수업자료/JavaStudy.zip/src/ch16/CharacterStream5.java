package ch16;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class CharacterStream5 {
  public static void main(String[] args) throws IOException {
    Writer writer = new FileWriter("chracter-stream-write.txt");

    String str = "Java";

    writer.write(str);

    writer.flush();
    writer.close();
  }
}
