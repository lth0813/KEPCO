package ch16;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class CharacterStream3 {
  public static void main(String[] args) throws IOException {
    Writer writer = new FileWriter("character-stream-write.txt");
        
    writer.write('J');
    writer.write('a');
    writer.write('v');
    writer.write('a');
    
    writer.flush();
    writer.close();
  }
}
