package ch10;

public class Parent {
  
  public void run() {
    System.out.println("Parent run");
  }
  
}
