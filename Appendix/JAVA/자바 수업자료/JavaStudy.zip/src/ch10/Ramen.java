package ch10;

public class Ramen {
  String taste;
  String name;

  public String getTaste() {
    return "라면맛";
  }
}