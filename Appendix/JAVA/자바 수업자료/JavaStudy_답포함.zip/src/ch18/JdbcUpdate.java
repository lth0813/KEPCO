package ch18;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JdbcUpdate {
  private static final String DRIVER_CLASS_NAME = "org.mariadb.jdbc.Driver";
  private static final String URL = "jdbc:mariadb://localhost:3306/java";
  private static final String USERNAME = "root";
//  private static final String URL = "jdbc:mariadb://15.164.153.191:3306/java";
//  private static final String USERNAME = "java";
  private static final String PASSWORD = "1234";
  
  public static void main(String[] args) throws ClassNotFoundException, SQLException {
    Class.forName(DRIVER_CLASS_NAME);
    Connection con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
   
    String sql = "UPDATE java_board SET " +
                 " title = ?, content = ? WHERE id = ?";
    
    PreparedStatement stmt = con.prepareStatement(sql);
    stmt.setString(1, "제목 1번 수정");
    stmt.setString(2, "내용 1번 수정");
    stmt.setInt(3, 1);
    
    int result = stmt.executeUpdate();
    
    stmt.close();
    con.close();
  }
}
