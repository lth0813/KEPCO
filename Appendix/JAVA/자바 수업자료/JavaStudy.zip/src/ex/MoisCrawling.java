package ex;

import java.io.IOException;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class MoisCrawling {
  public static void main(String[] args) throws IOException {
    Connection con = 
      Jsoup.connect(
        "https://www.mois.go.kr/frt/bbs/type010/commonSelectBoardList.do" + 
        "?bbsId=BBSMSTR_000000000008&pageIndex=1");
    
    Document doc = con.post();
    
    Element doc_totle = doc.selectFirst(".doc_totle");
    System.out.println(doc_totle.text());
    
    Elements trs = doc.select("[name=subForm] table > tbody > tr");
    
    for(Element tr : trs) {
      String result = "";
      Elements tds = tr.select("td");
      for(int i = 0; i < tds.size(); i++) {
        // 2, 5 인덱스 생략
        if(i == 2 || i == 5) continue;
        result += tds.get(i).text() + " ";
      }
      System.out.println(result);
    }
  }
}
