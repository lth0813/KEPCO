package ch10;

public class SaltyRamen      { // 상속 코드 작성
//  public SaltyRamen(String name) {
//    super.name = name;
//  }

  // 오버라이드 코드 작성

  
  
  
}