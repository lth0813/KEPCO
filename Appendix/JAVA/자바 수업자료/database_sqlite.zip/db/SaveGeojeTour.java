package db;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

import db.dao.TourDao;
import db.dto.TourDto;

public class SaveGeojeTour {
  public static final String authApiKey = "A2usf4txsthrBPXx7%2FckSjISrlOOF3DRCXlpwxFKcl1KPyvOOWSD%2FUhcapvCkM51AdZOieooIvkMdz2XQCt33w%3D%3D";
  
  public static void main(String[] args) throws IOException {
    int pageSize = 80;
    
    String apiURL = "http://data.geoje.go.kr/rfcapi/rest/geojetour/getGeojetourList";
    apiURL += "?authApiKey=" + authApiKey;
    apiURL += "&pageSize=" + pageSize;
    
    URL url = new URL(apiURL);
    HttpURLConnection con = (HttpURLConnection) url.openConnection();
    con.setRequestProperty("accept", "application/json");
    
    ObjectMapper objectMapper = new ObjectMapper();
    Map object = objectMapper.readValue(con.getInputStream(), Map.class);
    
    Map body = (Map) object.get("body");
    Map data = (Map) body.get("data");
    List list = (List) data.get("list");
    
    TourDao dao = new TourDao();
    for(int i = 0; i < list.size(); i++) {
      Map tour = (Map) list.get(i);
      String id = (String) tour.get("geojetourId");
      String name = (String) tour.get("geojetourNm");
      String address = (String) tour.get("geojetourAddr");
      String desc = (String) tour.get("geojetourDesc");
      String simpleDesc = (String) tour.get("geojetourSimpleDesc");
      String tel = (String) tour.get("geojetourTel");
      String code = (String) tour.get("geojetourCd");
      String codeName = (String) tour.get("geojetourCdNm");
      String mainImg = (String) tour.get("geojetourMainImg");
      String homepage = (String) tour.get("geojetourHomepage");
      String mapInfo = (String) tour.get("geojetourMapInfo");
      String latitude = (String) tour.get("geojetourYpos");
      String longitude = (String) tour.get("geojetourXpos");
      
      TourDto dto = new TourDto();
      dto.setId(Integer.parseInt(id));
      dto.setName(name);
      dto.setAddress(address);
      dto.setDesc(desc);
      dto.setSimpleDesc(simpleDesc);
      dto.setTel(tel);
      dto.setCode(code);
      dto.setCodeName(codeName);
      dto.setMainImg(mainImg);
      dto.setHomepage(homepage);
      dto.setMapInfo(mapInfo);
      dto.setLatitude(latitude);
      dto.setLongitude(longitude);
      
      dao.save(dto);
    }
  }
}
