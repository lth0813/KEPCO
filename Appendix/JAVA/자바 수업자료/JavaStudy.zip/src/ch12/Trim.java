package ch12;

public class Trim {
  public static void main(String args[]) {
    String str = "  Java Programming  ";
    System.out.println("@" + str + "@");
    
    str = str.trim();
    System.out.println(str);
  }
}