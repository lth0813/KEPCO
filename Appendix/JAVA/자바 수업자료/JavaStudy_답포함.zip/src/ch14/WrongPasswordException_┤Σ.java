package ch14;

public class WrongPasswordException_답 extends Exception {
  public WrongPasswordException_답() {
    this("아이디가 존재하지 않습니다.");
  }

  public WrongPasswordException_답(String msg) {
    super(msg);
  }
}
