package ch07;

public class 연습문제02Main {
  public static void main(String[] args) {
//    e = new     ;
//    e.content = "Hello World!";
//    e.latitude = 33.450701f;
//    e.longitude = 126.570667f;
//    
//    System.out.println(e);
  }
}
