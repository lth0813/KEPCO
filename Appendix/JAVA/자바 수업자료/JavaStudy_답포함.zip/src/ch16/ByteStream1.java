package ch16;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class ByteStream1 {
  public static void main(String[] args) throws IOException {
    InputStream in = new FileInputStream("byte-stream-data.txt");
    
    while(true) {
      int data = in.read();   
      
      if(data == -1) break;

      System.out.printf("%s", (char) data);
    }
    
    in.close();
  }
}
