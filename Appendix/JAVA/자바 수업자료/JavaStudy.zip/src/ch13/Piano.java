package ch13;

public class Piano implements Soundable {
  @Override
  public String sound() {
    return "도레미";
  }
}
