package ch16;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class 연습문제03_답 {
  public static void main(String[] args) throws IOException {
    Writer writer = new FileWriter("src/ch16/writer.txt");
    writer.write("파일\n");
    writer.write("출력");
    writer.flush();
    writer.close();
  }
}
