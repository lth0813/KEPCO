package ch15;

import java.util.LinkedList;

public class LinkedListExam {
  public static void main(String args[]) {
    LinkedList<String> linkedList = new LinkedList<String>();

    linkedList.add("A");
    linkedList.add("B");
    linkedList.add("C");
    linkedList.add("D");
    linkedList.add("E");

    for (int i = 0; i < linkedList.size(); i++) {
      System.out.println(linkedList.get(i));
    }
    
    linkedList.remove(4);
    linkedList.remove(3);

    linkedList.add(0, "=> D");
    linkedList.add(1, "=> E");

    for (int i = 0; i < linkedList.size(); i++) {
      System.out.println(linkedList.get(i));
    }
  }
}
