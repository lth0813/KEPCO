package ch05;

public class 연습문제02 {
  public static void main(String[] args) {
    char[] nums = { 'a', 'b', 'c', 'd', 'e', 'f', 'g' };
    for (int i = 0; i < nums.length - 1; i++) {
      
//      int position =     ;

      
      
      
    }
    System.out.println(nums);
  }
}
