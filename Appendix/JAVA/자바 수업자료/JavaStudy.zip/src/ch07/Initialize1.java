package ch07;

public class Initialize1 {
  // 멤버(전역) 변수
  int x;  // 자동 초기화 O
  int y = x;

  public static void main(String[] args) {
    // 메소드(지역) 변수
    int a;  // 자동 초기화 X
//    int b = a;
  }
}
