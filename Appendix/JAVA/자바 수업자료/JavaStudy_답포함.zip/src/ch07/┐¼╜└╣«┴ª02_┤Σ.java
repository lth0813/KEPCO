package ch07;

public class 연습문제02_답 {
  String content;
  float latitude;
  float longitude;
}
