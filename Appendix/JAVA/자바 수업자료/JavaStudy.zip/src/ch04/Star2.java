package ch04;

public class Star2 {
  public static void main(String[] args) {
    
    for (int a = 5; a >= 1; a--) {
      
      for (int b = a; b >= 1; b--) {
        System.out.print("*");
      }
      
      System.out.println();
      
    }
  }
}
