package ch06;

public class MethodExam4 {
  static int num = 10;

  public static void main(String[] args) {
    int num = 20;
    System.out.println(num);
  }

  public static void temp() {
    int num = 30;
    System.out.println(num);
  }
}
