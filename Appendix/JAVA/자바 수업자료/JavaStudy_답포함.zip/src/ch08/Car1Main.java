package ch08;

public class Car1Main {
  public static void main(String[] args) {
    Car1 car = new Car1();
    System.out.println(car.color);
    System.out.println(car.door);
  }
}
