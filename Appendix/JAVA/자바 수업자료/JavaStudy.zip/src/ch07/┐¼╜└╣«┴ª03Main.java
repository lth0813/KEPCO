package ch07;

public class 연습문제03Main {
  public static void main(String[] args) {
    연습문제03.method1();
  }
}
