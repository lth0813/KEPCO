package db;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

import db.dao.FoodDao;
import db.dto.FoodDto;

public class SaveGeojeFood {
  public static final String authApiKey = "A2usf4txsthrBPXx7%2FckSjISrlOOF3DRCXlpwxFKcl1KPyvOOWSD%2FUhcapvCkM51AdZOieooIvkMdz2XQCt33w%3D%3D";
  
  public static void main(String[] args) throws IOException {
    int pageSize = 140;
    
    String apiURL = "http://data.geoje.go.kr/rfcapi/rest/geojefood/getGeojefoodList";
    apiURL += "?authApiKey=" + authApiKey;
    apiURL += "&pageSize=" + pageSize;
    
    URL url = new URL(apiURL);
    HttpURLConnection con = (HttpURLConnection) url.openConnection();
    con.setRequestProperty("accept", "application/json");
    
    ObjectMapper objectMapper = new ObjectMapper();
    Map object = objectMapper.readValue(con.getInputStream(), Map.class);
    
    Map body = (Map) object.get("body");
    Map data = (Map) body.get("data");
    List list = (List) data.get("list");
    
    FoodDao dao = new FoodDao();
    for(int i = 0; i < list.size(); i++) {
      Map food = (Map) list.get(i);
      String id = (String) food.get("geojefoodId");
      String name = (String) food.get("geojefoodNm");
      String address = (String) food.get("geojefoodAddr");
      String desc = (String) food.get("geojefoodDesc");
      String tel = (String) food.get("geojefoodTel");
      String latitude = (String) food.get("geojefoodYpos");
      String longitude = (String) food.get("geojefoodXpos");
      
      FoodDto dto = new FoodDto();
      dto.setId(Integer.parseInt(id));
      dto.setName(name);
      dto.setAddress(address);
      dto.setDesc(desc);
      dto.setTel(tel);
      dto.setLatitude(latitude);
      dto.setLongitude(longitude);
      
      dao.save(dto);
    }
  }
}
