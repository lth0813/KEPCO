package ch15;

import java.util.HashMap;

public class HashMapExam {
  public static void main(String[] args) {
HashMap<String, String> map = new HashMap<String, String>();
map.put("B", "2");
map.put("A", "1");
map.put("D", "4");
map.put("C", "3");
System.out.println(map);

map.put("A", "10");
System.out.println(map);
  }
}
