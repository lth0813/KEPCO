package ex;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

public class VisionKakaoAPI {
  public static final String restAPIKey = "f33c0bdc28cf3a49a87aeb9f5e218e65";

  public static void main(String[] args) throws IOException {
    sendFile("images/einstein.jpg");
    sendUrl("https://ohfun.net/contents/article/images/2016/0419/1461048508650111.jpeg");
  }
  
  public static void sendFile(String imageFile) throws IOException {
    String result = "";
    File uploadFile = new File(imageFile);
    String apiURL = "https://dapi.kakao.com/v2/vision/face/detect";
    URL url = new URL(apiURL);
    HttpURLConnection con = (HttpURLConnection) url.openConnection();
    con.setRequestProperty("Authorization", "KakaoAK " + restAPIKey);

    con.setUseCaches(false);
    con.setDoOutput(true);
    con.setDoInput(true);

    String boundary = "---" + System.currentTimeMillis() + "---";
    con.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

    OutputStream outputStream = con.getOutputStream();
    PrintWriter writer = new PrintWriter(
        new OutputStreamWriter(outputStream, "UTF-8"), true);
    String LINE_FEED = "\r\n";

    String fileName = uploadFile.getName();
    writer.append("--" + boundary).append(LINE_FEED);
    writer.append(
        "Content-Disposition: form-data; name=\"image\"; filename=\"" + fileName +
        "\"").append(LINE_FEED);
    writer.flush();
    
    result += "--" + boundary + LINE_FEED;
    result += "Content-Disposition: form-data; name=\"image\"; filename=\"" + fileName + "\"" + LINE_FEED;

    FileInputStream inputStream = new FileInputStream(uploadFile);
    while (true) {
      int read = inputStream.read();
      if (read == -1) break;
      outputStream.write(read);
      result += read;
    }

    writer.append(LINE_FEED);
    writer.append(boundary + "--").append(LINE_FEED);
    writer.close();
    
    result += LINE_FEED;
    result += boundary + "--" + LINE_FEED;

    inputStream.close();
    outputStream.close();

    ObjectMapper objectMapper = new ObjectMapper();
    Map<String, Object> object = objectMapper.readValue(con.getInputStream(), Map.class);
    System.out.println(object);
    System.out.println(result);
  }

  public static void sendUrl(String imageUrl) throws IOException {
    String apiURL = "https://dapi.kakao.com/v2/vision/face/detect";
    URL url = new URL(apiURL);
    HttpURLConnection con = (HttpURLConnection) url.openConnection();
    con.setUseCaches(false);
    con.setDoOutput(true);
    con.setDoInput(true);

    con.setRequestProperty("Authorization", "KakaoAK " + restAPIKey);

    OutputStream outputStream = con.getOutputStream();
    PrintWriter writer = new PrintWriter(new OutputStreamWriter(outputStream, "UTF-8"), true);
    writer.append("image_url=" + imageUrl);
    writer.flush();
    outputStream.flush();
    writer.close();

    ObjectMapper objectMapper = new ObjectMapper();
    Map<String, Object> object = objectMapper.readValue(con.getInputStream(), Map.class);
    System.out.println(object);
  }
}
