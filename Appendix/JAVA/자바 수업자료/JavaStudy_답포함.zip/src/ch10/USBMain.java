package ch10;

public class USBMain {

  public static void main(String[] args) {
    S_USB usb = new S_USB();
    usb.copy();
    usb.checkCapacity();
  }
  
}