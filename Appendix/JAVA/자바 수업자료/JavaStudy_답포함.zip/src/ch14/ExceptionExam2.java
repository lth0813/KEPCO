package ch14;

public class ExceptionExam2 {
  public static void main(String[] args) {
    String numStr = " 123";
    try {
      int num = Integer.parseInt(numStr);
    } catch (NumberFormatException e) {
      System.out.println(e.getMessage());
    } finally {
      System.out.println("항상 실행 1");
    }
    
    Object obj = new String("a");
    try {
      int a = (Integer) obj;
    } catch (ClassCastException e) {
      System.out.println(e.getMessage());
    } finally {
      System.out.println("항상 실행 2");
    }
  }
}
