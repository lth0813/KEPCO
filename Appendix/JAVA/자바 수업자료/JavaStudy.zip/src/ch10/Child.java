package ch10;

public class Child extends Parent {
  
  @Override
  public void run() {
    System.out.println("Overriding");
    System.out.println("Child run");
  }
  
}
