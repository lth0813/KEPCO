package ch17;

public class MyThread extends Thread {
  @Override
  public void run() {
    /* 동작 코드 */
  }
}
