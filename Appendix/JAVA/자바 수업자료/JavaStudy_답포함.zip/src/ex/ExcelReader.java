package ex;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
  public static void readXls(String file) throws IOException {
    FileInputStream fis = new FileInputStream(file);
    HSSFWorkbook workbook = new HSSFWorkbook(fis);
    HSSFSheet sheet = workbook.getSheetAt(0);
    int rows = sheet.getPhysicalNumberOfRows();
  
    for (int rowNo = 3; rowNo < rows; rowNo++) {
      HSSFRow row = sheet.getRow(rowNo);
      if (row != null) {
        int cells = row.getPhysicalNumberOfCells();
        
        HSSFCell cell1 = row.getCell(1);
        HSSFCell cell2 = row.getCell(2);
        HSSFCell cell3 = row.getCell(3);
        HSSFCell cell4 = row.getCell(cells - 1);
  
        System.out.printf(
            "%s %s %s %s\n", (int)cell1.getNumericCellValue(), 
            (int) cell2.getNumericCellValue(), 
            cell3.getStringCellValue(), cell4.getStringCellValue());
      }
    }
    
    workbook.close();
  }
    
  public static void readXlsx(String file) throws IOException {
    FileInputStream fis = new FileInputStream(file);
    XSSFWorkbook workbook = new XSSFWorkbook(fis);
    XSSFSheet sheet = workbook.getSheetAt(0);
    int rows = sheet.getPhysicalNumberOfRows();
    
    for (int rowNo = 3; rowNo < rows; rowNo++) {
      XSSFRow row = sheet.getRow(rowNo);
      if (row != null) {
        int cells = row.getPhysicalNumberOfCells();
        
        XSSFCell cell1 = row.getCell(1);
        XSSFCell cell2 = row.getCell(2);
        XSSFCell cell3 = row.getCell(3);
        XSSFCell cell4 = row.getCell(cells - 1);
  
        System.out.printf(
            "%s %s %s %s\n", (int)cell1.getNumericCellValue(), 
            (int) cell2.getNumericCellValue(), 
            cell3.getStringCellValue(), cell4.getStringCellValue());
      }
    }
    
    workbook.close();
  }
    
  public static void main(String[] args) {
    try {
      readXls("data/excel.xls");
      readXlsx("data/excel.xlsx");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
