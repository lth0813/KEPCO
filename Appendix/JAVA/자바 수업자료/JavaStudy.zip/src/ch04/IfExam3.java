package ch04;

import java.util.Scanner;

public class IfExam3 {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    System.out.println("두 수를 입력해주세요. ex) 10 20");
    int num1 = scan.nextInt();
    int num2 = scan.nextInt();

    System.out.println("첫번째 숫자 => " + num1);
    System.out.println("두번째 숫자 => " + num2);

    if (num1 > num2) {
      System.out.println("첫번째 숫자가 더 큽니다.");
    } else if (num1 < num2) {
      System.out.println("두번째 숫자가 더 큽니다.");
    } else {
      System.out.println("두 수가 같습니다.");
    }
    
    scan.close();
  }
}
