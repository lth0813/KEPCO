package ch04;

public class SwitchExam2 {
  public static void main(String[] args) {
    String alphabet = "A";

    switch (alphabet) {
    case "A":
    case "a":
      System.out.println("입력된 값은 A");
      break;
    case "B":
      System.out.println("입력된 값은 B");
      break;
    default:
      System.out.println("A도 아니고 B도 아님");
    }
  }
}
