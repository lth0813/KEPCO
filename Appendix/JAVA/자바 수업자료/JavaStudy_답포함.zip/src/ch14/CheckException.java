package ch14;

public class CheckException extends Exception {

  public CheckException(String message) {
    super(message);
  }

}
