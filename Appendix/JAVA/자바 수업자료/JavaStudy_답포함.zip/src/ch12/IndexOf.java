package ch12;

public class IndexOf {
  public static void main(String args[]) {
    String str = "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.";

    int idx = str.indexOf(" ");
    System.out.println(idx);

    int idx2 = str.lastIndexOf(" ");
    System.out.println(idx2);

    idx = str.indexOf(" ", idx + 1);
    System.out.println(idx);

    idx2 = str.lastIndexOf(" ", idx2 - 1);
    System.out.println(idx2);
  }
}
