package ch04;

import java.util.Calendar;

public class 연습문제01 {
  public static void main(String[] args) {
    Calendar calendar = Calendar.getInstance();
    int year = calendar.get(Calendar.YEAR);
    System.out.printf("현재 연도는 %s년\n", year);
    
  }
}
