package ch15;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class IteratorExam {
  public static void main(String[] args) {
//    ArrayList<String> data = new ArrayList<String>();
//    data.add("1번"); data.add("2번"); data.add("3번");

    LinkedList<String> data = new LinkedList<String>();
    data.add("1번"); data.add("2번"); data.add("3번");
    
    Iterator<String> iter = data.iterator();
    while (iter.hasNext()) {
      String item = iter.next();
      System.out.println(item);
    }
  }
}
