package ch14;

public class NotExistIdException_답 extends Exception {
  public NotExistIdException_답() {
    this("아이디가 존재하지 않습니다.");
  }

  public NotExistIdException_답(String msg) {
    super(msg);
  }
}
