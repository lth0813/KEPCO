package ch04;

public class 연습문제04_답 {
  public static void main(String[] args) {
    for(int i = 1; i <= 20; i++) {
      System.out.print((i < 10 ? "0" + i : i)  + " ");
      if(i % 5 == 0) {
        System.out.println();
      }
    }    
  }
}
