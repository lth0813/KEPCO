package ch15;

import java.util.ArrayList;

public class ArrayListExam {
  public static void main(String[] args) {
    // arrayList 이름을 가진 ArrayList 생성
    ArrayList<String> arrayList = new ArrayList<String>();

    // ArrayList 에 element 추가
    arrayList.add("1번");
    arrayList.add("2번");
    arrayList.add("3번");

    // ArrayList 에 element 추가
    arrayList.add("=> 4번");
    arrayList.add("=> 5번");

    for (int i = 0; i < arrayList.size(); i++) {
      System.out.println(arrayList.get(i));
    }
    // ArrayList의 4번째와 5번째 element를 삭제
    arrayList.remove(4);
    arrayList.remove(3);

    // ArrayList 에 index를 부여한 element 추가
    arrayList.add(0, "=> 4번");
    arrayList.add(1, "=> 5번");

    for (int i = 0; i < arrayList.size(); i++) {
      System.out.println(arrayList.get(i));
    }
  }
}
