package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBConnector {
  private static final String DRIVER_CLASS_NAME = "org.sqlite.JDBC";
  private static final String URL = "c:\\study\\geoje.db";

  private DBConnector() {}
  
  public static Connection open() {
    Connection con = null;
    try {
      Class.forName(DRIVER_CLASS_NAME);
      con = DriverManager.getConnection("jdbc:sqlite:" + URL);
    } catch (ClassNotFoundException e) {
      System.out.println("드라이버를 찾을 수 없음");
    } catch (SQLException e) {
      System.out.println("연결 실패");
    }
    return con;
  }
  
  public static void close(
      Connection con, 
      PreparedStatement stmt, ResultSet rs) {

    if(rs != null) {
      try { rs.close(); } 
      catch (SQLException e) { e.printStackTrace(); }
    }
    
    if(stmt != null) {
      try { stmt.close(); } 
      catch (SQLException e) { e.printStackTrace(); }
    }
    
    if(con != null) {
      try { con.close(); } 
      catch (SQLException e) { e.printStackTrace(); }
    }

  }
}


