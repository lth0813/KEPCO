package ch08;

public class Car2 {
  String color;
  int door;

  public Car2(String c, int d) {
    color = c;
    door = d;
  }
}
