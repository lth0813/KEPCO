package ch04;

public class 연습문제04 {
  public static void main(String[] args) {
//    for(    ) {
//      System.out.print(    );
//      if(    ) {
//        System.out.println();
//      }
//    }    
  }
}
