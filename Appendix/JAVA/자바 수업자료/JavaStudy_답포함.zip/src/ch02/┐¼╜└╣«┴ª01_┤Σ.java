package ch02;

public class 연습문제01_답 {
  public static void main(String[] args) {
    boolean a = false;
    char b = 'a';
    int c = 20;
    long d = 2147483648L;
    float e = 3.14f;
    double f = 1.0;
    
    System.out.println(a);
    System.out.println(b);
    System.out.println(c);
    System.out.println(d);
    System.out.println(e);
    System.out.println(f);
  }
}
