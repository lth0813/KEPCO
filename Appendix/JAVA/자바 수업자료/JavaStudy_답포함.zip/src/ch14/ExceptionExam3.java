package ch14;

public class ExceptionExam3 {
  public static void main(String[] args) throws NumberFormatException, ClassCastException {
    String numStr = " 123";
    int num = Integer.parseInt(numStr);

    Object obj = new String("a");
    int a = (Integer) obj;
  }
}
