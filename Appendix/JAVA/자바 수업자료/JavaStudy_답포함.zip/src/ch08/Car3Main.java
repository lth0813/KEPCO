package ch08;

public class Car3Main {
  public static void main(String[] args) {
    Car3 car = new Car3();
    System.out.println(car.color);
    System.out.println(car.door);

    Car3 car2 = new Car3("빨강");
    System.out.println(car2.color);
    System.out.println(car2.door);

    Car3 car3 = new Car3("노랑", 2);
    System.out.println(car3.color);
    System.out.println(car3.door);
  }
}
