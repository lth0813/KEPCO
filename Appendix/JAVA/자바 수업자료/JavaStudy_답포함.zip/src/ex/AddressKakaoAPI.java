package ex;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AddressKakaoAPI {
public static final String restAPIKey = "f33c0bdc28cf3a49a87aeb9f5e218e65";

public static void main(String[] args) throws IOException {
  String query = "부산 연제구 중앙대로 1001";

  String apiURL = "https://dapi.kakao.com/v2/local/search/address.json";
  apiURL += "?query=" + URLEncoder.encode(query, "utf-8");

  URL url = new URL(apiURL);
  HttpURLConnection con = (HttpURLConnection) url.openConnection();
  con.setRequestProperty("Authorization", "KakaoAK " + restAPIKey);

  ObjectMapper objectMapper = new ObjectMapper();
  Map<String, Object> object = objectMapper.readValue(con.getInputStream(), Map.class);
  System.out.println(object);

  List<Map> documents = (List<Map>) object.get("documents");
  for (Map document : documents) {
    String addressName = (String) document.get("address_name");
    String latitude = (String) document.get("y");
    String longitude = (String) document.get("x");
    System.out.println(addressName);
    System.out.printf("%s / %s\n", latitude, longitude);
  }
}
}
