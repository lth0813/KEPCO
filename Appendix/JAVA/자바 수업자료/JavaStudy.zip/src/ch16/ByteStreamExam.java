package ch16;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class ByteStreamExam {
  public static void main(String[] args) throws IOException {
    InputStream in = new FileInputStream("byte-stream-data.txt");
    
    int letter = in.read();   
    System.out.printf("ASCII 값 : %s\n", letter);
    System.out.printf("문자 형태로 변환된 값 %s\n", (char) letter);
    
    letter = in.read();   
    System.out.printf("ASCII 값 : %s\n", letter);
    System.out.printf("문자 형태로 변환된 값 %s\n", (char) letter);
    
    in.close();
  }
}
