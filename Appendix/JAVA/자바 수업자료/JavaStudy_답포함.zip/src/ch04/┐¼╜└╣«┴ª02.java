package ch04;

public class 연습문제02 {
  public static void main(String[] args) {
    int a = 1;
    int b = 1;
    int c = 2;
    
  }
}
