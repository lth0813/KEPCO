package ch16;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class FileIO {
  public static void main(String[] args) throws IOException {
    InputStream in = new FileInputStream("character-stream-data.txt");
    InputStreamReader isr = new InputStreamReader(in);
    BufferedReader reader = new BufferedReader(isr);
    
    OutputStream out = new FileOutputStream("character-stream-data-copy.txt");
    OutputStreamWriter osw = new OutputStreamWriter(out);
    BufferedWriter writer = new BufferedWriter(osw);
    
    String data = "";
    while (true) {
      data = reader.readLine();
      if(data == null) break;
      System.out.println(data);
      writer.write(data);
    }
    
    reader.close();
    isr.close();
    in.close();
    
    writer.close();
    osw.close();
    out.close();
  }
}
