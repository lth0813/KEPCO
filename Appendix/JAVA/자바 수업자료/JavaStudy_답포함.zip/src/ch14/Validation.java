package ch14;

import java.rmi.AccessException;

public class Validation {
  private String numStr;
  private String num;
  
  public void setNumStr(String numStr) {
    this.numStr = numStr;
  }
  public void setNum(String num) {
    this.num = num;
  }

  public void check() throws AccessException {
    try {
      int num = Integer.parseInt(this.numStr);

      Object obj = new String(this.num);
      int a = (Integer) obj;
    } catch (NumberFormatException e) {
      throw new AccessException("숫자변환 실패");
    } catch (ClassCastException e) {
      throw new AccessException("형변환 실패");
    }
  }
}
