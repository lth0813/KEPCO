package ex;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class SMTPAuthenticatorNaver extends Authenticator {

  @Override
  protected PasswordAuthentication getPasswordAuthentication() {
    return new PasswordAuthentication(
        "ssaltoki@naver.com", "spdlqj12!@");
  }

}
