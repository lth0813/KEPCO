package ch13;

public class IpTimeRouter extends Router {
  public String connect() {
    return "iptime connect";
  }
  public String disconnect() {
    return "iptime disconnect";
  }
}
