package ch07;

public class PersonMain {
  public static void main(String[] args) {
Person p1 = new Person();
p1.name = "김길동";
p1.height = 170.4f;
p1.weight = 70.0f;

System.out.printf(
    "이름 : %s, 키 : %s, 몸무게 : %s\n", 
    p1.name, p1.height, p1.weight);

Person p2 = new Person();
p2.name = "이길동";
p2.height = 171.1f;
p2.weight = 75.4f;

System.out.printf(
    "이름 : %s, 키 : %s, 몸무게 : %s\n", 
    p2.name, p2.height, p2.weight);
  }
}
