package ch13;

public abstract class AbstractChild extends AbstractParent {
  public abstract void run();
}
