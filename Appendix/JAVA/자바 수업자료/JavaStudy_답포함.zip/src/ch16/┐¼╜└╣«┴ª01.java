package ch16;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class 연습문제01 {
  public static void main(String[] args) throws IOException {
//    OutputStream out =     ;
    
    
    
//    out.flush();
//    out.close();
  }
}
