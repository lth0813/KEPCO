package ch07;

public class 연습문제03 {
  int a; // int a = 0;

  public static void method1() {
    System.out.println("method1 실행 시작");

        ;
    for (int i = 0; i < 5; i++) {
          ;  // method2 호출
    }
    
    System.out.println("method1 실행 종료");
  }

  public void method2() {
        ; // 전역변수 a의 값을 1 씩 증가
    System.out.printf("method2 : %s\n", a); // 전역변수 a의 값 출력
  }
}
