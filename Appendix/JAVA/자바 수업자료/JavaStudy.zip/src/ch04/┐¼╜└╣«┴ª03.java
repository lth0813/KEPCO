package ch04;

import java.awt.Desktop;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class 연습문제03 {
  private static MouseAdapter adapter = new MouseAdapter() {
    public void mouseClicked(MouseEvent e) {
      JButton btn = (JButton) e.getComponent();
      String name = btn.getText(); // 버튼의 글자
      String link = "";
      

      
      
      try {
        Desktop.getDesktop().browse(new URI(link)); // 웹사이트 접속
      } catch (IOException | URISyntaxException e1) {
        e1.printStackTrace();
      }
    };
  };
  
  public static void main(String[] args) {
    JFrame j = new JFrame("웹사이트 접속");
    
    JPanel p = new JPanel(new GridLayout(1, 2));
    JButton b1 = new JButton("Bloter");
    JButton b2 = new JButton("ZDNet");
    p.add(b1);
    p.add(b2);
    j.add(p);
    
    b1.addMouseListener(adapter);
    b2.addMouseListener(adapter);
    
    j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    j.setSize(300, 100);
    j.setLocation(300, 300);
    j.setVisible(true);
  }
}
