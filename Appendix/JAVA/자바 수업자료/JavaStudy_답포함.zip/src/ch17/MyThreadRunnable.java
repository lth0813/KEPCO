package ch17;

public class MyThreadRunnable implements Runnable {
  @Override
  public void run() {
    /* 동작 코드 */
  }
}
