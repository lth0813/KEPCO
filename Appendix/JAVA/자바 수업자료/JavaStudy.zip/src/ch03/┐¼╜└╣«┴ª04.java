package ch03;

public class 연습문제04 {
  public static void main(String[] args) {
    int num = 10;
    
    System.out.println(   );
  }
}
