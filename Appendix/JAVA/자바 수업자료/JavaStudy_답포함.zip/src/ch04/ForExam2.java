package ch04;

public class ForExam2 {
  public static void main(String[] args) {
    int sum = 0;
    
    for (int i = 1; i <= 10; i++) {
      sum = sum + i;
      
      System.out.print("i의 값 => " + i);
      System.out.println(" sum의 값 => " + sum);
    }
  }
}
