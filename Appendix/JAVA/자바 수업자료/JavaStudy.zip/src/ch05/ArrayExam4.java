package ch05;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class ArrayExam4 {
  public static void main(String[] args) {
    char[] chars = { 'b', 'e', 'z', 'a', 'w' };
    char temp = ' ';
    for (int i = 0; i < chars.length - 1; i++) {
      
      for (int j = i + 1; j < chars.length; j++) {
        
        if (chars[i] > chars[j]) {
          temp = chars[i];
          chars[i] = chars[j];
          chars[j] = temp;
        }
    
      }
    }
    System.out.println(chars);
    
    Character[] chars2 = { 'b', 'e', 'z', 'a', 'w' };
    
    Arrays.sort(chars2);
    System.out.println(Arrays.toString(chars2));
    
    Arrays.sort(chars2, new Comparator<Character>() {
      @Override
      public int compare(Character o1, Character o2) {
        return o2.compareTo(o1);
      }
    });
    System.out.println(Arrays.toString(chars2));
    
    Arrays.sort(chars2, Collections.reverseOrder());
    System.out.println(Arrays.toString(chars2));

  }
}
