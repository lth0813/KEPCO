package ch05;

public class 연습문제02_답 {
  public static void main(String[] args) {
    char[] nums = { 'a', 'b', 'c', 'd', 'e', 'f', 'g' };
    for (int i = 0; i < nums.length - 1; i++) {
      
      int position = (int) (Math.random() * nums.length);
      
      char temp = nums[i];
      nums[i] = nums[position];
      nums[position] = temp;
      
    }
    System.out.println(nums);
  }
}
