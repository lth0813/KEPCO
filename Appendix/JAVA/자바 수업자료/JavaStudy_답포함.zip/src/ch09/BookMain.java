package ch09;

public class BookMain {
  public static void main(String[] args) {
    Book book = new Book();

    BookStore store = new BookStore();
    store.append(book);
    store.print();
  }
}
