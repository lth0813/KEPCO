package db;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

import db.dao.ShopDao;
import db.dto.ShopDto;

public class SaveGeojeShop {
  public static final String authApiKey = "A2usf4txsthrBPXx7%2FckSjISrlOOF3DRCXlpwxFKcl1KPyvOOWSD%2FUhcapvCkM51AdZOieooIvkMdz2XQCt33w%3D%3D";
  
  public static void main(String[] args) throws IOException {
    int pageSize = 30;
    
    String apiURL = "http://data.geoje.go.kr/rfcapi/rest/geojegoodshop/getGeojegoodshopList";
    apiURL += "?authApiKey=" + authApiKey;
    apiURL += "&pageSize=" + pageSize;
    
    URL url = new URL(apiURL);
    HttpURLConnection con = (HttpURLConnection) url.openConnection();
    con.setRequestProperty("accept", "application/json");
    
    ObjectMapper objectMapper = new ObjectMapper();
    Map object = objectMapper.readValue(con.getInputStream(), Map.class);
    
    Map body = (Map) object.get("body");
    Map data = (Map) body.get("data");
    List list = (List) data.get("list");
    
    ShopDao dao = new ShopDao();
    for(int i = 0; i < list.size(); i++) {
      Map shop = (Map) list.get(i);
      String id = (String) shop.get("goodshopId");
      String name = (String) shop.get("goodshopNm");
      String address = (String) shop.get("goodshopAddr");
      String info = (String) shop.get("goodshopInfo");
      String tel = (String) shop.get("goodshopTel");
      String code = (String) shop.get("goodshopCd");
      String codeName = (String) shop.get("goodshopCdNm");
      String mainImg = (String) shop.get("goodshopIdMainImg");
      
      ShopDto dto = new ShopDto();
      dto.setId(Integer.parseInt(id));
      dto.setName(name);
      dto.setAddress(address);
      dto.setInfo(info);
      dto.setTel(tel);
      dto.setCode(code);
      dto.setCodeName(codeName);
      dto.setMainImg(mainImg);
      
      dao.save(dto);
    }
  }
}
