package ch07;

public class Student {

}
