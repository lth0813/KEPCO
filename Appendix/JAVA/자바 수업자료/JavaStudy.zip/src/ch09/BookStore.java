package ch09;

public class BookStore {
  Book book;

  public void append(Book book) {
    this.book = book;
  }

  public void remove(Book book) {
    this.book = null;
  }

  public void print() {
    System.out.println(book.toString());
  }
}
