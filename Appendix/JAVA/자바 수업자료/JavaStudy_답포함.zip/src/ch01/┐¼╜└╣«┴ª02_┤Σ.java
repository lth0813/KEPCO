package ch01;

public class 연습문제02_답 {
  public static void main(String[] args) {
    System.out.println("{");
    System.out.println("  \"id\": \"abcd\",");
    System.out.println("  \"pw\": 1234,");
    System.out.println("  \"name\": \"park\",");
    System.out.println("  \"age\": 20");
    System.out.println("}");
  }
}
