package ch10;

public class OverloadingExam {
  void change(int num) { }

  void change(char ch) { }

  void change(int num, char ch) { }

  // int change(int num) { } // 반환 타입만 다른 경우 오류, 동일 메소드로 인식
}
