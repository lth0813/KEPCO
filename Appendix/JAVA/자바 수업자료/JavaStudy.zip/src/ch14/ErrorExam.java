package ch14;

import java.io.File;

public class ErrorExam {
  public static void main(String[] args) {
//    int a = 1.2; // compile
    
    // runtime
    System.out.println(4 / 0); // Arithmetic
    System.out.println(new String().charAt(1)); // IndexOutOfBounds
    String str = null;
    System.out.println(str.equals("")); // NullPointer
    
    int[] arrs = new int[-1]; // NegativeArraySize
    
    String s = "Exception";
    int count = s.indexOf("a");
    int[] arrays = new int[count]; // NegativeArraySize
    System.out.println(arrays);
    
//    new File("").createNewFile();
  }
}
