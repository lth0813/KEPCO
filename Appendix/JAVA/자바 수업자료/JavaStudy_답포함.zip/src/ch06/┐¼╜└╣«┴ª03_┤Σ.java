package ch06;

public class 연습문제03_답 {
  public static void main(String[] args) {
    String result = gugudan(2, 9);
    System.out.println(result);
  }
  
  public static String gugudan(int start, int end) {
    String result = "";
    for (int i = start; i <= end; i++) {
      for (int j = 1; j <= 9; j++) {
        result += i + " * " + j + " = " + (i * j) + "\n";
      }
    }
    return result;
  }
}
