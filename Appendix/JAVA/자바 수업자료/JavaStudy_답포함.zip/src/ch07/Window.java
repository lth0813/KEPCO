package ch07;

import javax.swing.JFrame;

public class Window {
  public static void main(String[] args) {
    JFrame frame = new JFrame("윈도우");
    
    frame.setSize(300, 200);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    frame.setVisible(true);
  }
}
