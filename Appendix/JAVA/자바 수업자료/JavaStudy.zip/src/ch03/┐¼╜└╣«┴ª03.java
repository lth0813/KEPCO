package ch03;

public class 연습문제03 {
  public static void main(String[] args) {
    int num = 12345;
    
//    int num1 = 
//    int num2 = 
//    int num3 = 
//    int num4 = 
//    int num5 = 
//    
//    int total = num1 + num2 + num3 + num4 + num5;
//    System.out.println("각 자리 숫자의 합 : " + total);
  }
}
