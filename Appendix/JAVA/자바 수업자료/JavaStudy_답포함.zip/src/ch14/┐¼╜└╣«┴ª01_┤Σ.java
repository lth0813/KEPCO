package ch14;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class 연습문제01_답 {
  public static void main(String[] args) {
    BufferedReader reader = null;
    try {
      reader = new BufferedReader(new FileReader("data/소나기.txt"));
      
      String text = "";
      
      while(true) {
        String data = reader.readLine();
        if(data == null) break;
        text += data + "\n";
      }
      System.out.println(text);
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      try {
        if(reader != null) reader.close();
      } catch (IOException e) {
        e.printStackTrace();
      }      
    }
  }
}
