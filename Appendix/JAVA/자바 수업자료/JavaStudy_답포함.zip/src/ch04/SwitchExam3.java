package ch04;

public class SwitchExam3 {
  public static void main(String[] args) {
    Week w = Week.MON;

    switch (w) {
    case MON:
      System.out.println("월요일");
      break;
    case TUE:
      System.out.println("화요일");
      break;
    default:
       System.out.println("잘못된 입력");
    }
  }
}

enum Week {
  MON, TUE, WED, THU, FRI, SAT, SUN
}
