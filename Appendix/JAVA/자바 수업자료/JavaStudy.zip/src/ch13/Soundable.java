package ch13;

public interface Soundable {
  String sound();
}
