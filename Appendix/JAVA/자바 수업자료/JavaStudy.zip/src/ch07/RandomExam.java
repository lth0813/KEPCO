package ch07;

public class RandomExam {
  public static void main(String[] args) {
    double num = Math.random();
    System.out.println(num);
  }
}
