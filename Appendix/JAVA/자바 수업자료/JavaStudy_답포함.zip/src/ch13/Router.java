package ch13;

public class Router {
  public String connect() {
    return "connect";
  }
  public String disconnect() {
    return "disconnect";
  }
}
