package ch08;

public class Car5Main {
  public static void main(String[] args) {
    Car5 car = new Car5();
    System.out.println(car.color);
    System.out.println(car.door);

    Car5 car2 = new Car5("빨강");
    System.out.println(car2.color);
    System.out.println(car2.door);

    Car5 car3 = new Car5("노랑", 2);
    System.out.println(car3.color);
    System.out.println(car3.door);
  }
}
