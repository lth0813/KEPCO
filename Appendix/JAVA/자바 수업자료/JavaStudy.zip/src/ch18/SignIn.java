package ch18;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class SignIn {
  private static final String DRIVER_CLASS_NAME = "org.mariadb.jdbc.Driver";
  private static final String URL = "jdbc:mariadb://localhost:3306/java";
  private static final String USERNAME = "root";
//  private static final String URL = "jdbc:mariadb://15.164.153.191:3306/java";
//  private static final String USERNAME = "java";
  private static final String PASSWORD = "1234";
  
  public static void main(String[] args) throws ClassNotFoundException, SQLException {
    Scanner scanId = new Scanner(System.in);
    Scanner scanPw = new Scanner(System.in);
      
    String id = scanId.nextLine();
    String pw = scanPw.nextLine();
      
    scanId.close();
    scanPw.close();
      
    Class.forName(DRIVER_CLASS_NAME);
    Connection con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
     
    String sql = "SELECT * FROM java_member WHERE id = ? AND pw = ?";
    
    PreparedStatement stmt = con.prepareStatement(sql);
    stmt.setString(1, id);
    stmt.setString(2, pw);
    
    ResultSet rs = stmt.executeQuery();
    
    String result = "";
    if(rs.next()) {
      result = "로그인 성공";
    } else {      
      result = "로그인 실패";
    }
    System.out.println(result);
    
    rs.close();
    stmt.close();
    con.close();
  }
}
