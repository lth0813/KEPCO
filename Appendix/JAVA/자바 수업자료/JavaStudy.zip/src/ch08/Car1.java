package ch08;

public class Car1 {
  String color;
  int door;

  public Car1() {
    color = "빨강";
    door = 2;
  }
}
