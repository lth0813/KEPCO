package ch10;

public class Ramen_답 {
  String taste;
  String name;

  public String getTaste() {
    return "라면맛";
  }
}