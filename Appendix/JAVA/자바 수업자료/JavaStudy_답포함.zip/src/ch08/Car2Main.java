package ch08;

public class Car2Main {
  public static void main(String[] args) {
    Car2 car = new Car2("빨강", 2);
    
    System.out.println(car.color);
    System.out.println(car.door);
  }
}
