package ch12;

public class Substring {
  public static void main(String args[]) {
    //            0         10        20        30
    //            012345678901234567890123456789012
    String str = "Life is too short, You need Java?";
    
    String str1 = str.substring(19);
    System.out.println(str1);
    
    String str2 = str.substring(12, 17);
    System.out.println(str2);
    
    String str3 = str.substring(28, 32);
    System.out.println(str3);
  }
}
