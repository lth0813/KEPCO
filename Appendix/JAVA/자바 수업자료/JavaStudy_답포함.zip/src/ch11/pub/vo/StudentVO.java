package ch11.pub.vo;

public class StudentVO {
  public int grade;
  public int classNum;
  public String name;
}
