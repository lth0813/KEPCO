package ch13;

public class Guitar implements Soundable {
  @Override
  public String sound() {
    return "팅";
  }
}
