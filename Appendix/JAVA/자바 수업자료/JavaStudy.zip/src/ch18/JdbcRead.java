package ch18;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JdbcRead {
  private static final String DRIVER_CLASS_NAME = "org.mariadb.jdbc.Driver";
  private static final String URL = "jdbc:mariadb://localhost:3306/java";
  private static final String USERNAME = "root";
//  private static final String URL = "jdbc:mariadb://15.164.153.191:3306/java";
//  private static final String USERNAME = "java";
  private static final String PASSWORD = "1234";
  
  public static void main(String[] args) throws ClassNotFoundException, SQLException {
    Class.forName(DRIVER_CLASS_NAME);
    Connection con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
   
    String sql = "SELECT id, title, content, member_id, cre_date " +
                 "  FROM java_board";
    
    PreparedStatement stmt = con.prepareStatement(sql);
    ResultSet rs = stmt.executeQuery();
    while(rs.next()) {
      int id = rs.getInt("id");
      String title = rs.getString("title");
      String content = rs.getString("content");
      String member_id = rs.getString("member_id");
      String cre_date = rs.getString("cre_date");
      
      System.out.printf(
          "id : %s, title: %s, content : %s,\n" +
          "member_id : %s, cre_date : %s\n", 
          id, title, content, member_id, cre_date);
    }
    rs.close();
    stmt.close();
    con.close();
  }
}
