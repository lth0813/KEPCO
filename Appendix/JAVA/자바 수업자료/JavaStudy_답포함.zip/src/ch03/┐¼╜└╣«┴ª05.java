package ch03;

public class 연습문제05 {
  public static void main(String[] args) {
    char ch = 'T';
    
//    char lowerCase = (    ) ?    : ch;

    System.out.println("입력된 문자 : " + ch);
//    System.out.println("소문자로 변경된 문자 : " + lowerCase);
  }
}
