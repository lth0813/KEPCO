package ch07;

public class Constants {
  public static final int HOBBY_SWIMMING = 0;
  public static final int HOBBY_TENNIS = 1;
  public static final int HOBBY_EAT = 2;
}
