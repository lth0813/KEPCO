package ch03;

public class 연습문제04_답 {
  public static void main(String[] args) {
    int num = 10;
    
    System.out.println(  num % 2 == 0 ? "짝수" : "홀수"  );
  }
}
