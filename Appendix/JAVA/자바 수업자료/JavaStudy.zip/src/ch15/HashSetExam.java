package ch15;

import java.util.HashSet;

public class HashSetExam {
  public static void main(String args[]) {
    HashSet<String> hs = new HashSet<String>();

    hs.add("1");
    hs.add("A");
    hs.add("3");
    hs.add("B");
    hs.add("2");
    hs.add("C");

    System.out.println(hs);
  }
}
