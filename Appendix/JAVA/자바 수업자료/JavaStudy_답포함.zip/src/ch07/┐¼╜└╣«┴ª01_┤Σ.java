package ch07;

public class 연습문제01_답 {
  String[] images;
  String shopName;
  String shopDesc;
  String tel;
  String address;
  int hit;
}
