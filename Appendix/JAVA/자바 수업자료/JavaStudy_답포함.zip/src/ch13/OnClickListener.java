package ch13;

public interface OnClickListener {
  void onClick();
}
