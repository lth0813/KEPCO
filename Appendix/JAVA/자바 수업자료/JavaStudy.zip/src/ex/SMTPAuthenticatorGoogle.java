package ex;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class SMTPAuthenticatorGoogle extends Authenticator {

  @Override
  protected PasswordAuthentication getPasswordAuthentication() {
    return new PasswordAuthentication(
        "ggoreb.kim@gmail.com", "dnwgrqhykrsuvuok");
  }
	
}
