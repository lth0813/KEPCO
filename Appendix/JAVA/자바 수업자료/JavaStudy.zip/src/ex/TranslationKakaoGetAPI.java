package ex;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

public class TranslationKakaoGetAPI {
  public static final String restAPIKey = "f33c0bdc28cf3a49a87aeb9f5e218e65";
  
  public static void main(String[] args) throws IOException {
    String source = "kr"; // 번역 대상 언어
    String target = "en"; // 번역 결과 언어
    String query = "94년 제가 LA에 처음 갔을 때 모든 경기 하나하나가 참 힘들었습니다.\n하지만 포기하지 않았습니다."; // 번역 대상 문장
    
    String apiURL = "https://dapi.kakao.com/v2/translation/translate";
    apiURL += "?src_lang=" + source;
    apiURL += "&target_lang=" + target;
    apiURL += "&query=" + URLEncoder.encode(query, "utf-8");
    
    URL url = new URL(apiURL);
    HttpURLConnection con = (HttpURLConnection) url.openConnection();
    con.setRequestProperty("Authorization", "KakaoAK " + restAPIKey);
    
    ObjectMapper objectMapper = new ObjectMapper();
    Map<String, Object> object = objectMapper.readValue(con.getInputStream(), Map.class);
    System.out.println(object);
    
    List<List> list = (List<List>) object.get("translated_text");
    for(List<String> li : list) {
      for(String text : li) {
        System.out.println(text);
      }
    }
  }
}
