package ex;

public class JsonVO {
  String name;
  int age;
  
  public String getName() { return name; }
  public void setName(String name) { this.name = name; }
  
  public int getAge() { return age; }
  public void setAge(int age) { this.age = age;}
  
  @Override
  public String toString() {
    return "JsonVO [name=" + name + ", age=" + age + "]";
  }
  
//  int id;
//  int pw;
//  
//  public int getId() { return id; }
//  public void setId(int id) { this.id = id; }
//
//  public int getPw() { return pw; }
//  public void setPw(int pw) { this.pw = pw; }
//
//  @Override
//  public String toString() {
//    return "JsonVO [id=" + id + ", pw=" + pw + "]";
//  }
}
