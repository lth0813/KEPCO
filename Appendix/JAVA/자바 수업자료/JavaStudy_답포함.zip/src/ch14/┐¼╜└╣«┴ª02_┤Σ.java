package ch14;

public class 연습문제02_답 {
  public static void main(String[] args) {
    연습문제02_답 e = new 연습문제02_답();
    
    try {
      e.login("white", 1234);
    } catch (NotExistIdException_답 e1) {
      e1.printStackTrace();
    } catch (WrongPasswordException_답 e1) {
      e1.printStackTrace();
    }
    
    try {
      e.login("blue", 4321);
    } catch (NotExistIdException_답 e1) {
      e1.printStackTrace();
    } catch (WrongPasswordException_답 e1) {
      e1.printStackTrace();
    }
  }
  
  public void login(String id, int pw) throws NotExistIdException_답, WrongPasswordException_답 {
    if(!id.equals("blue")) {
      throw new NotExistIdException_답();
    }
    if(pw != 1234) {
      throw new WrongPasswordException_답();      
    }
  }
}
