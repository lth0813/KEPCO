package ch14;

public class 연습문제02 {
  public static void main(String[] args) {
    연습문제02 e = new 연습문제02();
    
    e.login("white", 1234);
    
    e.login("blue", 4321);
  }
  
  public void login(String id, int pw)      {
    if(!id.equals("blue")) {
      
    }
    if(pw != 1234) {
            
    }
  }
}
