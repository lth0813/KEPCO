package ch04;

public class 연습문제05 {
  public static void main(String[] args) {
    int n = 5;
    int space = 0;

//    for(    ) {
//      space =     ;
//      for(    ) {
//        
//        
//      }
//      System.out.println();
//    }
  }
}
