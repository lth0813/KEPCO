package ch03;

public class Operation1 {
  public static void main(String[] args) {
    int a = 10;

    a = -a; // a의 값을 음수로
    System.out.println(a);

    System.out.println(a++); // a의 값 출력 후 증가

    System.out.println(a); // 위의 증가된 a의 값 확인

    System.out.println(--a); // a의 값 감소 후 출력
    
    boolean b = true;
    System.out.println(b);

    b = !b; // b의 값 논리 부정
    System.out.println(b);

    char c1 = 'a';
    char c2 = c1++;
    char c3 = ++c1;
    System.out.println(c2);
    System.out.println(c3);

  }
}
