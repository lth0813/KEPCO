package ch16;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FileExam2 {
  public static void main(String[] args) throws IOException {
    File text = new File("text");
    File[] files = text.listFiles();
    System.out.println("시간\t\t\t형태\t\t크기\t이름");
    System.out.println("------------------------------------------------------");
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd a HH:mm");
    
    for(File f : files) {
      System.out.print(format.format(new Date(f.lastModified())));
      if(f.isDirectory()) {
        System.out.print("\t<DIR>\t\t\t" + f.getName());
      } else { 
        System.out.print("\t\t\t" + f.length() + "\t" + f.getName());
      }
      System.out.println();
    }
  }
}
