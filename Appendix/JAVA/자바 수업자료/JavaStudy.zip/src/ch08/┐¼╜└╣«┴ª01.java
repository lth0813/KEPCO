package ch08;

public class 연습문제01 {
  float bottom;
  float height;
  
  // 기본 생성자 작성
  
  // 매개변수 2개 생성자 작성
  
  // getArea 메소드 작성

  // bottom과 height의 setter 메소드 작성

}
