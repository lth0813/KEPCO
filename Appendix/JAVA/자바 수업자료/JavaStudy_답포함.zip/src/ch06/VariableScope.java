package ch06;

public class VariableScope {
  boolean globalScope = true;

  public static void main(String[] args) {
    boolean localScope = true;
    if (localScope) {
      int num = 1;
      System.out.println(num);
    } else {
      int num = 2;
      System.out.println(num);
    }
    simple();

    for (int num = 0; num < 5; num++) {
      /*
       * int num = 0; 중복선언, 사용불가
       */
    }

  }

  public static void simple() {
    int num = 3;
    System.out.println(num);
  }

  public static void method(int num) {
    /*
     * int num = 0; 중복선언, 사용불가
     */
  }

}