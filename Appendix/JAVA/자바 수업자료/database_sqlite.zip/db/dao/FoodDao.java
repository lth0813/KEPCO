package db.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import db.DBConnector;
import db.dto.FoodDto;

public class FoodDao {
  
  public int save(FoodDto foodDto) {
    makeDB();
    
    Connection con = DBConnector.open();
    PreparedStatement stmt = null;
    
    int result = 0;

    try {
      StringBuffer sql = new StringBuffer();
      sql.append("INSERT INTO food");
      sql.append("  (id, name, address, desc, tel, latitude, longitude)");
      sql.append("  VALUES");
      sql.append("  (?, ?, ?, ?, ?, ?, ?)");      
      
      stmt = con.prepareStatement(sql.toString());
      stmt.setInt(1, foodDto.getId());
      stmt.setString(2, foodDto.getName());
      stmt.setString(3, foodDto.getAddress());
      stmt.setString(4, foodDto.getDesc());
      stmt.setString(5, foodDto.getTel());
      stmt.setString(6, foodDto.getLatitude());
      stmt.setString(7, foodDto.getLongitude());
      
      result = stmt.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      DBConnector.close(con, stmt, null);
    }
    return result;
  }
  
  private boolean makeDB() {
    Connection con = DBConnector.open();
    PreparedStatement stmt = null;
    
    int result = 0;
    
    try {
      StringBuffer sql = new StringBuffer();
      sql.append("CREATE TABLE IF NOT EXISTS food (");
      sql.append("  id INTEGER PRIMARY KEY,");
      sql.append("  name TEXT,");
      sql.append("  address TEXT,");
      sql.append("  desc TEXT,");
      sql.append("  tel TEXT,");
      sql.append("  latitude TEXT,");
      sql.append("  longitude TEXT");
      sql.append(");");      
      
      stmt = con.prepareStatement(sql.toString());      
      result = stmt.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      DBConnector.close(con, stmt, null);
    }
    return result == 1 ? true : false;
  }
}
