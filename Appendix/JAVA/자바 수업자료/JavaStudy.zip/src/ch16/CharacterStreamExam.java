package ch16;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class CharacterStreamExam {
  public static void main(String[] args) throws IOException {
    
    Reader reader = new FileReader("byte-stream-data.txt");
    
    int letter = reader.read();
    System.out.printf("ASCII 값 : %s\n", letter);
    System.out.printf("문자 형태로 변환된 값 %s\n", (char) letter);
    
    letter = reader.read();
    System.out.printf("ASCII 값 : %s\n", letter);
    System.out.printf("문자 형태로 변환된 값 %s\n", (char) letter);
    
    reader.close();
  }
}
