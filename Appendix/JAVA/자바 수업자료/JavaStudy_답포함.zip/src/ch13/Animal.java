package ch13;

public abstract class Animal {
  public abstract void sound();
}
