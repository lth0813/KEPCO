package ch10;

public class SaltyRamen_답 extends Ramen_답 { // 상속 코드 작성
  public SaltyRamen_답(String name) {
    super.name = name;
  }

  // 오버라이드 코드 작성
  @Override
  public String getTaste() {
    return this.name + " => " + "짠 라면맛";
  }  
  
}