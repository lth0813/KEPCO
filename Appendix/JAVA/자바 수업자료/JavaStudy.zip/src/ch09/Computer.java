package ch09;

public class Computer {
  int cpu;

  public Computer() {
  }

  public Computer(int cpu) {
    this.cpu = cpu;
  }

  public int getCpu() {
    return cpu;
  }

  public void setCpu(int cpu) {
    this.cpu = cpu;
  }
}
