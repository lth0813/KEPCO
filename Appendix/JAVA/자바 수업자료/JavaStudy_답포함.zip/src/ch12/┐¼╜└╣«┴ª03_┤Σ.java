package ch12;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class 연습문제03_답 {
  public static void main(String[] args) throws IOException {
    /* 소나기.txt 문자열 읽어오기 */
    BufferedReader reader = new BufferedReader(new FileReader("data/소나기.txt"));
    String text = "";
    while(true) {
      String data = reader.readLine();
      if(data == null) break;
      text += data + "\n";
    }
    reader.close();
    
    int startIdx = 0;
    int endIdx = 0;
    while(true) {
      startIdx = text.indexOf("칡", endIdx);
      if(startIdx == -1) break;
      endIdx = text.indexOf(".", startIdx);
      System.out.println(text.substring(startIdx, endIdx + 1));
    }
  }
}







