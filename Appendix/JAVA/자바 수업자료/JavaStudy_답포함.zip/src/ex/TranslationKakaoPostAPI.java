package ex;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

public class TranslationKakaoPostAPI {
  public static final String restAPIKey = "f33c0bdc28cf3a49a87aeb9f5e218e65";
  
  public static void main(String[] args) throws IOException {
    String source = "kr"; // 번역 대상 언어
    String target = "en"; // 번역 결과 언어
    String query = "94년 제가 LA에 처음 갔을 때 모든 경기 하나하나가 참 힘들었습니다.\n하지만 포기하지 않았습니다."; // 번역 대상 문장
    
    String apiURL = "https://dapi.kakao.com/v2/translation/translate";
    URL url = new URL(apiURL);
    HttpURLConnection con = (HttpURLConnection) url.openConnection();
    con.setRequestMethod("POST");
    con.setDoOutput(true);
    con.setDoInput(true);

    con.setRequestProperty("Authorization", "KakaoAK " + restAPIKey);
    
    OutputStream outputStream = con.getOutputStream();
    PrintWriter writer = new PrintWriter(new OutputStreamWriter(outputStream, "UTF-8"), true);
    writer.append("src_lang=" + source);
    writer.append("&target_lang=" + target);
    writer.append("&query=" + query);
    writer.flush();
   
    ObjectMapper objectMapper = new ObjectMapper();
    Map<String, Object> object = objectMapper.readValue(con.getInputStream(), Map.class);
    System.out.println(object);
    
    List<List> list = (List<List>) object.get("translated_text");
    for(List<String> li : list) {
      for(String text : li) {
        System.out.println(text);
      }
    }
  }
}
