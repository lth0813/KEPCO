package ch10;

public class 연습문제01_답 {
  public static void main(String[] args) {
    Ramen_답 ramen1 = new SpicyRamen_답("불 라면");
    String taste1 = ramen1.getTaste();
    System.out.println(taste1);
    Ramen_답 ramen2 = new SaltyRamen_답("소금 라면");
    String taste2 = ramen2.getTaste();
    System.out.println(taste2);
  }
}
