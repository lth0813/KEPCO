package ch14;

import java.rmi.AccessException;

public class ExceptionExam4 {
  
  public static void main(String[] args) {
    
    Validation valid = new Validation();

    try {
      valid.check();
    } catch (AccessException e) {
      e.printStackTrace();
    }
    
  }

}
