package ch01;

public class 연습문제01_답 {
  public static void main(String[] args) {
    System.out.println("1 + 2 + 3 의 연산 결과는 '6' 입니다.");
    System.out.println("1 + 2 + 3 의 연산 결과는 \"6\" 입니다.");
    
    int a = 1, b = 2, c = 3, d = 4, e = 5;
    System.out.println( // a ~ e 변수를 활용하여 연산
        "1 ~ 5 까지의 곱셈 결과는 " + (a * b * c * d * e) + " 입니다.");
  }
}
