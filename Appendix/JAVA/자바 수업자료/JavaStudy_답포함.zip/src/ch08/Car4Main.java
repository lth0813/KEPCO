package ch08;

public class Car4Main {
  public static void main(String[] args) {
    Car4 car = new Car4();
    System.out.println(car.getColor());
    System.out.println(car.getDoor());

    Car4 car2 = new Car4("blue", 4);
    System.out.println(car2.getColor());
    System.out.println(car2.getDoor());
  }
}
