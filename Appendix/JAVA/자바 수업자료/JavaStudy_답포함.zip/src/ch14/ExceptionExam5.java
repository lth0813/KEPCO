package ch14;

import java.io.File;
import java.io.IOException;

public class ExceptionExam5 {
  public static void main(String[] args) {
    File file = new File("c:/test.txt");
    
    // check exception
    try {
      file.createNewFile();
    } catch (IOException e) {
      e.printStackTrace();
    }

    // uncheck exception
    String str = null;
    str.length();
  }
}
