package ch07;

public class Person {
  String name; // 이름
  float height; // 키
  float weight; // 몸무게
}
