package db.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import db.DBConnector;
import db.dto.TourDto;

public class TourDao {
  
  public int save(TourDto tourDto) {
    makeDB();
    
    Connection con = DBConnector.open();
    PreparedStatement stmt = null;
    
    int result = 0;

    try {
      StringBuffer sql = new StringBuffer();
      sql.append("INSERT INTO tour");
      sql.append("  (id, name, address, desc, simpleDesc, tel, code, codeName, mainImg, homepage, mapInfo, latitude, longitude)");
      sql.append("  VALUES");
      sql.append("  (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");      
      
      stmt = con.prepareStatement(sql.toString());
      stmt.setInt(1, tourDto.getId());
      stmt.setString(2, tourDto.getName());
      stmt.setString(3, tourDto.getAddress());
      stmt.setString(4, tourDto.getDesc());
      stmt.setString(5, tourDto.getSimpleDesc());
      stmt.setString(6, tourDto.getTel());
      stmt.setString(7, tourDto.getCode());
      stmt.setString(8, tourDto.getCodeName());
      stmt.setString(9, tourDto.getMainImg());
      stmt.setString(10, tourDto.getHomepage());
      stmt.setString(11, tourDto.getMapInfo());
      stmt.setString(12, tourDto.getLatitude());
      stmt.setString(13, tourDto.getLongitude());
      
      result = stmt.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      DBConnector.close(con, stmt, null);
    }
    return result;
  }
  
  private boolean makeDB() {
    Connection con = DBConnector.open();
    PreparedStatement stmt = null;
    
    int result = 0;
    
    try {
      StringBuffer sql = new StringBuffer();
      sql.append("CREATE TABLE IF NOT EXISTS tour (");
      sql.append("  id INTEGER PRIMARY KEY,");
      sql.append("  name TEXT,");
      sql.append("  address TEXT,");
      sql.append("  desc TEXT,");
      sql.append("  simpleDesc TEXT,");
      sql.append("  tel TEXT,");
      sql.append("  code TEXT,");
      sql.append("  codeName TEXT,");
      sql.append("  mainImg TEXT,");
      sql.append("  homepage TEXT,");
      sql.append("  mapInfo TEXT,");
      sql.append("  latitude TEXT,");
      sql.append("  longitude TEXT");
      sql.append(");");      
      
      stmt = con.prepareStatement(sql.toString());      
      result = stmt.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      DBConnector.close(con, stmt, null);
    }
    return result == 1 ? true : false;
  }
}
