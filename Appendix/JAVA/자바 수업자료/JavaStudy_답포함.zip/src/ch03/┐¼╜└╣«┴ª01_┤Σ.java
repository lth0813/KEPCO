package ch03;

public class 연습문제01_답 {
  public static void main(String[] args) {
    char first = 'A';
    char second = 'a';
    
    boolean result = first > second;
    
    System.out.printf("A 가 a 보다 ASCII 값이 더 크다 => %s\n", result);
  }
}
