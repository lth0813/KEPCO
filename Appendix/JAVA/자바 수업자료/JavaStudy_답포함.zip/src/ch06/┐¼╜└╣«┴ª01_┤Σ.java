package ch06;

public class 연습문제01_답 {
  public static void main(String[] args) {
    gugudan();
  }
  
  public static void gugudan() {
    for (int i = 2; i <= 9; i++) {
      for (int j = 1; j <= 9; j++) {
        System.out.println(i + " * " + j + " = " + (i * j));
      }
    }
  }
}
