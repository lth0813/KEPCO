package ch16;

import java.io.File;
import java.io.IOException;

public class FileExam1 {
  public static void main(String[] args) throws IOException {
    File dir = new File("text");
    
    if(!dir.exists()) {
      dir.mkdirs();
    }
    
    File file1 = new File("text/file1.txt");
    if(!file1.exists()) file1.createNewFile();
    
    File file2 = new File("text/file2.txt");
    if(!file2.exists()) file2.createNewFile();
    
    File file3 = new File("text/file3.txt");
    if(!file3.exists()) file3.createNewFile();
    
    File text = new File("text");
    File[] files = text.listFiles();
    for(File f : files) {
      System.out.println(f.getName());
      System.out.println(f.getPath());
    }
  }
}
