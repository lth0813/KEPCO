package ch12;

public class Length {
  public static void main(String[] args) {
    String str1 = "Java Programming";
    int str1Len = str1.length();
    System.out.println("str1Len : " + str1Len);
    
    String str2 = "자바 프로그래밍";
    int str2Len = str2.length();
    System.out.println("str2Len : " + str2Len);
    
    int str3Len = "이렇게도 가능".length();
    System.out.println("str3Len : " + str3Len);
  }
}
