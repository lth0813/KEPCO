package ch15;

import java.util.TreeSet;

public class TreeSetExam {
  public static void main(String[] args) {
    TreeSet<String> ts = new TreeSet<String>();

    ts.add("1");
    ts.add("A");
    ts.add("3");
    ts.add("B");
    ts.add("2");
    ts.add("C");

    System.out.println(ts);
  }
}
