package ch10;

public class Line3D extends Line2D {
  int z = 0;
  
  public String getLocation() {
    return super.getLocation() + ", z : " + z;
  }
}
