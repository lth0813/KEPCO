package ch04;

import java.io.IOException;

public class SwitchExam4 {
  public static void main(String[] args) throws IOException {
    System.out.println("한 글자만 입력해주세요.");
    int num = System.in.read();
    num = num - 48;

    switch (num) {
    case 0: case 1: case 2: case 3: case 4:
    case 5: case 6: case 7: case 8: case 9:
      System.out.println("0 ~ 9 숫자 입력!");
      break;
    default:
      System.out.println("문자 입력!");
    }
  }
}
