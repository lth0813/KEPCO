package ch13;

public class AnimalMain {
  public static void main(String[] args) {
    Animal animal1 = new Cat();
    animal1.sound();
    
    Animal animal2 = new Dog();
    animal2.sound();
  }
}
