package ch02;

public class 연습문제01 {
  public static void main(String[] args) {
//    a = false;
//    b = 'a';
//    c = 20;
//    d = 2147483648L;
//    e = 3.14f;
//    f = 1.0;
//    
//    System.out.println(a);
//    System.out.println(b);
//    System.out.println(c);
//    System.out.println(d);
//    System.out.println(e);
//    System.out.println(f);
  }
}
