package ch13;

public class MyClickListener implements OnClickListener {
  @Override
  public void onClick() {
    System.out.println("버튼 클릭 - 전화걸기");
  }
}