package ch08;

public class Car4 {
  String color = null;
  int door = 0;

  public Car4(String color, int door) {
    this.color = color;
    this.door = door;
  }

  public Car4(String color) {
    this(color, 4);
  }

  public Car4() {
  }

  public void setColor(String color) {
    this.color = color;
  }

  public String getColor() {
    return color;
  }

  public void setDoor(int door) {
    this.door = door;
  }

  public int getDoor() {
    return door;
  }
}
