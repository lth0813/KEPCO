package db.dto;

public class TourDto {
  private int id;
  private String name;
  private String address;
  private String desc;
  private String simpleDesc;
  private String tel;
  private String code;
  private String codeName;
  private String mainImg;
  private String homepage;
  private String mapInfo;
  private String latitude;
  private String longitude;
  
  public int getId() {
    return id;
  }
  public void setId(int id) {
    this.id = id;
  }
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  public String getAddress() {
    return address;
  }
  public void setAddress(String address) {
    this.address = address;
  }
  public String getDesc() {
    return desc;
  }
  public void setDesc(String desc) {
    this.desc = desc;
  }
  public String getSimpleDesc() {
    return simpleDesc;
  }
  public void setSimpleDesc(String simpleDesc) {
    this.simpleDesc = simpleDesc;
  }
  public String getTel() {
    return tel;
  }
  public void setTel(String tel) {
    this.tel = tel;
  }
  public String getCode() {
    return code;
  }
  public void setCode(String code) {
    this.code = code;
  }
  public String getCodeName() {
    return codeName;
  }
  public void setCodeName(String codeName) {
    this.codeName = codeName;
  }
  public String getMainImg() {
    return mainImg;
  }
  public void setMainImg(String mainImg) {
    this.mainImg = mainImg;
  }
  public String getHomepage() {
    return homepage;
  }
  public void setHomepage(String homepage) {
    this.homepage = homepage;
  }
  public String getMapInfo() {
    return mapInfo;
  }
  public void setMapInfo(String mapInfo) {
    this.mapInfo = mapInfo;
  }
  public String getLatitude() {
    return latitude;
  }
  public void setLatitude(String latitude) {
    this.latitude = latitude;
  }
  public String getLongitude() {
    return longitude;
  }
  public void setLongitude(String longitude) {
    this.longitude = longitude;
  }
}
