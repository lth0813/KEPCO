package ch09;

public class NoteBook extends Computer {

  public NoteBook() {
    super(3);
  }

  public NoteBook(int cpu) {
    super(cpu);
  }

}
