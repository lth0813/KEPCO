package ch17;

public class MyThreadMain{
  public static void main(String[] args) {
    MyThread m = new MyThread();
    m.start();
  }
}
