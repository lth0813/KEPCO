package ch10;

public class Top {
  int num = 10;
}
