package ch05;

public class ArrayExam2 {
  public static void main(String[] args) {
    
    int[] arr = { 100, 200, 300 };
    
    for (int a : arr) {
      System.out.println(a);
    }
    
  }
}
