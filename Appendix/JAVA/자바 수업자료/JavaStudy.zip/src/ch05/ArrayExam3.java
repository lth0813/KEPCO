package ch05;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class ArrayExam3 {
  public static void main(String[] args) {
    Integer[] numbers = { 3, 2, 1, 7, 4 };

    /* 반복문 */
    int min = 0;
    for (int i = 0; i < numbers.length; i++) {
      if (numbers[i] < min || min == 0) {
        min = numbers[i];
      }
    }
    System.out.printf("최소값 : %d\n", min);
    
    /* 정렬 */
    Arrays.sort(numbers); // 오름차순
    System.out.printf("최소값 : %d\n", numbers[0]);

    Arrays.sort(numbers, new Comparator<Integer>() { // 내림차순
      @Override
      public int compare(Integer o1, Integer o2) {
        return o2.compareTo(o1);
      }
    });
    System.out.printf("최소값 : %d\n", numbers[numbers.length-1]);
    
    Arrays.sort(numbers, Collections.reverseOrder()); // 내림차순
    System.out.printf("최소값 : %d\n", numbers[numbers.length-1]);
  }
}
