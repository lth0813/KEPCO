package ch13;

public interface IFigure {
  public abstract void area(int x, int y);
}
