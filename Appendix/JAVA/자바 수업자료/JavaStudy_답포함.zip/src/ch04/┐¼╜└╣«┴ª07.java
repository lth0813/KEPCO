package ch04;

import java.io.File;

public class 연습문제07 {
  public static void main(String[] args) {
    File file = new File("./src/ch04");
    File[] files = file.listFiles();
    
//    for (    ) {
//      String fileName = files[i].getName(); // 파일명 확인
//      
//      
//      
//      System.out.println(fileName);
//    }
  }
}
