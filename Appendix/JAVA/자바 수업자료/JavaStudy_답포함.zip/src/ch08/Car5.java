package ch08;

public class Car5 {
String color;
int door;

public Car5() {
  this("파랑", 4); // 자신의 생성자 호출
}

public Car5(String c) {
  this(c, 4);
}

public Car5(String c, int d) {
  color = c;
  door = d;
}
}
