package ch12;

public class Replace {
  public static void main(String[] args) {
    String str1 = "Java Programming 01~12";
    String str2 = null;
    String str3 = null;
    String str4 = null;
    
    str2 = str1.replace("Java", "자바");
    str3 = str1.replaceAll("[a-g]", "☆");
    str4 = str1.replaceAll("\\d", "X");
    System.out.println(str2);
    System.out.println(str3);
    System.out.println(str4);
  }
}
