package ch16;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class 연습문제04 {
  public static void main(String[] args) throws IOException {
//    Reader reader =     ;


    
    
    
//    reader.close();
  }
}
