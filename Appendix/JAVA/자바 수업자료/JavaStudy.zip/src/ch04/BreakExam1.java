package ch04;

public class BreakExam1 {
  public static void main(String[] args) {
    
    for (int i = 0; i < 10; i++) {
      System.out.println("현재값 : " + i);
    
      if (i == 5) {
        System.out.println("5가 되어 종료!");
        break;
      }
      
    }
    
  }
}
