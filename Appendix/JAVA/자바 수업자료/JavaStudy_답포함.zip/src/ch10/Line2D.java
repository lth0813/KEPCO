package ch10;

public class Line2D {
  int x = 0;
  int y = 0;
  
  public String getLocation() {
    return "x : " + x + ", y : " + y;
  }
}
