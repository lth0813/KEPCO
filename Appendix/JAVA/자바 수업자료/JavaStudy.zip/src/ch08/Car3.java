package ch08;

public class Car3 {
  String color;
  int door;

  public Car3() {
    color = "파랑";
    door = 4;
  }

  public Car3(String c) {
    color = c;
    door = 4;
  }

  public Car3(String c, int d) {
    color = c;
    door = d;
  }
}
