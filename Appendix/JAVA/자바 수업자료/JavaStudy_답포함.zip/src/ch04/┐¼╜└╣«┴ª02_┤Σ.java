package ch04;

public class 연습문제02_답 {
  public static void main(String[] args) {
    int a = 1;
    int b = 1;
    int c = 2;
    
    if(a >= b && a <= c || a >= c && a <= b) {
      System.out.printf("중간값은 a : %s", a);
    } else if(b >= a && b <= c || b >= c && b <= a) {
      System.out.printf("중간값은 b : %s", b);
    } else {
      System.out.printf("중간값은 c : %s", c);
    }
  }
}
