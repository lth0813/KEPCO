package ch10;

public class SuperThis2 {
  public static void main(String[] args) {
    Line3D line = new Line3D();
    
    String location = line.getLocation();
    
    System.out.println(location);
  }
}
