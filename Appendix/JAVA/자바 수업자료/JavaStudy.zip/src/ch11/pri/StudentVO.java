package ch11.pri;

public class StudentVO {
  private int grade;
  private int classNum;
  private String name;
}
