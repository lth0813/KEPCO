package ch16;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class ByteStream4 {
  public static void main(String[] args) throws IOException {
    OutputStream out = new FileOutputStream("byte-stream-write.txt");
    
    byte[] array = {
      (byte)'H', (byte)'e', (byte)'l', (byte)'l', (byte)'o'
    };
    
    out.write(array);
    
    out.flush();
    out.close();
  }
}
