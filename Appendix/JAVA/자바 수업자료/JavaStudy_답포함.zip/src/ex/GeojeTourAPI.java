package ex;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

public class GeojeTourAPI {
  public static final String authApiKey = "A2usf4txsthrBPXx7%2FckSjISrlOOF3DRCXlpwxFKcl1KPyvOOWSD%2FUhcapvCkM51AdZOieooIvkMdz2XQCt33w%3D%3D";
  
  public static void main(String[] args) throws IOException {
    int pageSize = 80;
    
    String apiURL = "http://data.geoje.go.kr/rfcapi/rest/geojetour/getGeojetourList";
    apiURL += "?authApiKey=" + authApiKey;
    apiURL += "&pageSize=" + pageSize;
    
    URL url = new URL(apiURL);
    HttpURLConnection con = (HttpURLConnection) url.openConnection();
    con.setRequestProperty("accept", "application/json");
    
    ObjectMapper objectMapper = new ObjectMapper();
    Map object = objectMapper.readValue(con.getInputStream(), Map.class);
    System.out.println(object);
    
    Map body = (Map) object.get("body");
    Map data = (Map) body.get("data");
    List list = (List) data.get("list");
    
    Writer writer = new FileWriter("geoje-tour.txt");
    
    for(int i = 0; i < list.size(); i++) {
      Map tour = (Map) list.get(i);
      String id = (String) tour.get("geojetourId");
      String name = (String) tour.get("geojetourNm");
      String address = (String) tour.get("geojetourAddr");
      String desc = (String) tour.get("geojetourDesc");
      String tel = (String) tour.get("geojetourTel");
      String latitude = (String) tour.get("geojetourYpos");
      String longitude = (String) tour.get("geojetourXpos");
      System.out.println(
          id + " | " + name + " | " + address + " | " + desc + " | " + 
          tel + " | " + latitude + " | " + longitude);
      writer.write(id + " | " + name + " | " + address + " | " + desc + " | " + 
          tel + " | " + latitude + " | " + longitude);
      writer.write("\n");
    }
    writer.close();
  }
}
